<?php $__env->startSection('container'); ?>
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-gray-800">Bookings Management</h1>
        <a href="<?php echo e(route('admin.bookings.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-2"></i> Add Booking
        </a>
    </div>

    <div class="bg-white rounded-lg shadow overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">People</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Notes</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4">
                            <p class="font-medium"><?php echo e($booking->customer_name); ?></p>
                            <p class="text-sm text-gray-500"><?php echo e($booking->customer_phone ?? '-'); ?></p>
                            <p class="text-sm text-gray-500"><?php echo e($booking->customer_email ?? '-'); ?></p>
                        </td>
                        <td class="px-6 py-4 font-semibold"><?php echo e($booking->booking_date); ?></td>
                        <td class="px-6 py-4"><?php echo e($booking->booking_time); ?></td>
                        <td class="px-6 py-4 text-center">
                            <span class="bg-gray-100 px-3 py-1 rounded-full"><?php echo e($booking->number_of_people); ?></span>
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 rounded text-xs
                                <?php if($booking->status === 'confirmed'): ?> bg-green-100 text-green-800
                                <?php elseif($booking->status === 'pending'): ?> bg-yellow-100 text-yellow-800
                                <?php elseif($booking->status === 'completed'): ?> bg-blue-100 text-blue-800
                                <?php else: ?> bg-red-100 text-red-800
                                <?php endif; ?>">
                                <?php echo e(ucfirst($booking->status)); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                            <?php echo e($booking->notes ?? '-'); ?>

                        </td>
                        <td class="px-6 py-4">
                            <div class="flex gap-2 flex-wrap">
                                <?php if($booking->status === 'pending'): ?>
                                    <form action="<?php echo e(route('admin.bookings.update-status', $booking)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="status" value="confirmed">
                                        <button type="submit" class="text-green-600 hover:underline text-sm">Confirm</button>
                                    </form>
                                    <form action="<?php echo e(route('admin.bookings.update-status', $booking)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="status" value="cancelled">
                                        <button type="submit" class="text-red-600 hover:underline text-sm">Cancel</button>
                                    </form>
                                <?php elseif($booking->status === 'confirmed'): ?>
                                    <form action="<?php echo e(route('admin.bookings.update-status', $booking)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="status" value="completed">
                                        <button type="submit" class="text-blue-600 hover:underline text-sm">Complete</button>
                                    </form>
                                <?php endif; ?>
                                <a href="<?php echo e(route('admin.bookings.edit', $booking)); ?>" class="text-blue-600 hover:underline text-sm">Edit</a>
                                <form action="<?php echo e(route('admin.bookings.delete', $booking)); ?>" method="POST" class="inline"
                                      onsubmit="return confirm('Delete this booking?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:underline text-sm">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="px-6 py-8 text-center text-gray-500">
                            No bookings yet
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($bookings->hasPages()): ?>
        <div class="mt-4">
            <?php echo e($bookings->links()); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xrey/Documents/my-scrum-project/resources/views/admin/bookings/index.blade.php ENDPATH**/ ?>