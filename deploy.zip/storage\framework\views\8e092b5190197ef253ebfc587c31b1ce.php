<?php $__env->startSection('container'); ?>
    <div class="mb-6">
        <h1 class="text-3xl font-bold text-gray-800">Dashboard Overview</h1>
        <p class="text-gray-500">Welcome back, <?php echo e(Auth::user()->name); ?>!</p>
    </div>

    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <!-- Pending Orders -->
        <div class="bg-gradient-to-br from-blue-500 to-blue-600 p-6 rounded-xl shadow-lg text-white">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm opacity-80">Pending Orders</p>
                    <h3 class="text-3xl font-bold"><?php echo e($pendingOrders); ?></h3>
                </div>
                <i class="fas fa-clock text-4xl opacity-50"></i>
            </div>
        </div>

        <!-- Pending Bookings -->
        <div class="bg-gradient-to-br from-amber-500 to-amber-600 p-6 rounded-xl shadow-lg text-white">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm opacity-80">Pending Bookings</p>
                    <h3 class="text-3xl font-bold"><?php echo e($pendingBookings); ?></h3>
                </div>
                <i class="fas fa-calendar-alt text-4xl opacity-50"></i>
            </div>
        </div>

        <!-- Total Products -->
        <div class="bg-gradient-to-br from-green-500 to-green-600 p-6 rounded-xl shadow-lg text-white">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm opacity-80">Total Products</p>
                    <h3 class="text-3xl font-bold"><?php echo e($totalProducts); ?></h3>
                </div>
                <i class="fas fa-box text-4xl opacity-50"></i>
            </div>
        </div>

        <!-- Total Users -->
        <div class="bg-gradient-to-br from-purple-500 to-purple-600 p-6 rounded-xl shadow-lg text-white">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm opacity-80">Total Users</p>
                    <h3 class="text-3xl font-bold"><?php echo e($totalUsers); ?></h3>
                </div>
                <i class="fas fa-users text-4xl opacity-50"></i>
            </div>
        </div>
    </div>

    <!-- Revenue & Orders Stats -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div class="bg-white p-6 rounded-xl shadow">
            <h3 class="text-lg font-semibold text-gray-700 mb-2">Today's Revenue</h3>
            <p class="text-3xl font-bold text-green-600">Rp <?php echo e(number_format($todayRevenue, 0, ',', '.')); ?></p>
        </div>
        <div class="bg-white p-6 rounded-xl shadow">
            <h3 class="text-lg font-semibold text-gray-700 mb-2">Total Orders</h3>
            <p class="text-3xl font-bold text-blue-600"><?php echo e($totalOrders); ?></p>
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Recent Orders -->
        <div class="bg-white p-6 rounded-xl shadow">
            <h3 class="text-lg font-semibold text-gray-700 mb-4">Recent Orders</h3>
            <div class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border-l-4 border-blue-500 pl-4 py-2 bg-gray-50 rounded-r">
                        <p class="font-semibold text-gray-800"><?php echo e($order->order_number); ?></p>
                        <p class="text-sm text-gray-600"><?php echo e($order->customer_name); ?> - Rp <?php echo e(number_format($order->total, 0, ',', '.')); ?></p>
                        <p class="text-xs text-gray-500"><?php echo e($order->created_at->diffForHumans()); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500 text-center py-4">No recent orders</p>
                <?php endif; ?>
            </div>
            <a href="<?php echo e(route('admin.orders.index')); ?>" class="block mt-4 text-blue-600 hover:underline text-sm">
                View all orders →
            </a>
        </div>

        <!-- Recent Bookings -->
        <div class="bg-white p-6 rounded-xl shadow">
            <h3 class="text-lg font-semibold text-gray-700 mb-4">Recent Bookings</h3>
            <div class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $recentBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border-l-4 border-amber-500 pl-4 py-2 bg-gray-50 rounded-r">
                        <p class="font-semibold text-gray-800"><?php echo e($booking->customer_name); ?></p>
                        <p class="text-sm text-gray-600"><?php echo e($booking->number_of_people); ?> people - <?php echo e($booking->booking_date); ?> <?php echo e($booking->booking_time); ?></p>
                        <span class="inline-block mt-1 text-xs px-2 py-0.5 rounded 
                            <?php if($booking->status === 'confirmed'): ?> bg-green-100 text-green-800
                            <?php elseif($booking->status === 'pending'): ?> bg-yellow-100 text-yellow-800
                            <?php else: ?> bg-gray-100 text-gray-800
                            <?php endif; ?>">
                            <?php echo e(ucfirst($booking->status)); ?>

                        </span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500 text-center py-4">No recent bookings</p>
                <?php endif; ?>
            </div>
            <a href="<?php echo e(route('admin.bookings.index')); ?>" class="block mt-4 text-blue-600 hover:underline text-sm">
                View all bookings →
            </a>
        </div>
    </div>

    <!-- Pending Approvals Alert -->
    <?php if($pendingOrders > 0 || $pendingBookings > 0): ?>
    <div class="mt-8 bg-red-50 border border-red-200 p-6 rounded-xl">
        <h3 class="text-lg font-semibold text-red-800 mb-4">
            <i class="fas fa-exclamation-triangle mr-2"></i>
            Pending Approvals
        </h3>
        <div class="space-y-2">
            <?php if($pendingOrders > 0): ?>
                <p class="text-red-700">
                    <i class="fas fa-shopping-cart mr-2"></i>
                    <?php echo e($pendingOrders); ?> order(s) waiting for confirmation
                    <a href="<?php echo e(route('admin.orders.index')); ?>" class="ml-4 underline">Review →</a>
                </p>
            <?php endif; ?>
            <?php if($pendingBookings > 0): ?>
                <p class="text-red-700">
                    <i class="fas fa-calendar mr-2"></i>
                    <?php echo e($pendingBookings); ?> booking(s) waiting for approval
                    <a href="<?php echo e(route('admin.bookings.index')); ?>" class="ml-4 underline">Review →</a>
                </p>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xrey/Documents/my-scrum-project/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>