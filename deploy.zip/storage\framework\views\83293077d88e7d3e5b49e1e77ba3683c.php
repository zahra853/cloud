<?php $__env->startSection('container'); ?>
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-gray-800">Orders Management</h1>
    </div>

    <div class="bg-white rounded-lg shadow overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Order #</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Items</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Payment</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 font-semibold"><?php echo e($order->order_number); ?></td>
                        <td class="px-6 py-4">
                            <p class="font-medium"><?php echo e($order->customer_name); ?></p>
                            <p class="text-sm text-gray-500"><?php echo e($order->user->email ?? '-'); ?></p>
                        </td>
                        <td class="px-6 py-4"><?php echo e($order->orderItems->count()); ?> items</td>
                        <td class="px-6 py-4 font-bold text-green-600">Rp <?php echo e(number_format($order->total, 0, ',', '.')); ?></td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 rounded text-xs
                                <?php if($order->status === 'completed'): ?> bg-green-100 text-green-800
                                <?php elseif($order->status === 'pending'): ?> bg-yellow-100 text-yellow-800
                                <?php elseif($order->status === 'processing'): ?> bg-blue-100 text-blue-800
                                <?php else: ?> bg-red-100 text-red-800
                                <?php endif; ?>">
                                <?php echo e(ucfirst($order->status)); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 rounded text-xs
                                <?php if($order->payment_status === 'paid'): ?> bg-green-100 text-green-800
                                <?php else: ?> bg-yellow-100 text-yellow-800
                                <?php endif; ?>">
                                <?php echo e(ucfirst($order->payment_status)); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-500"><?php echo e($order->created_at->format('d M Y H:i')); ?></td>
                        <td class="px-6 py-4">
                            <div class="flex gap-2">
                                <a href="<?php echo e(route('admin.orders.show', $order)); ?>" 
                                   class="text-blue-600 hover:underline text-sm">
                                    Detail
                                </a>
                                <?php if($order->status === 'pending'): ?>
                                    <form action="<?php echo e(route('admin.orders.update-status', $order)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="status" value="processing">
                                        <button type="submit" class="text-green-600 hover:underline text-sm">
                                            Process
                                        </button>
                                    </form>
                                <?php elseif($order->status === 'processing'): ?>
                                    <form action="<?php echo e(route('admin.orders.update-status', $order)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="status" value="completed">
                                        <button type="submit" class="text-green-600 hover:underline text-sm">
                                            Complete
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="px-6 py-8 text-center text-gray-500">
                            No orders yet
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($orders->hasPages()): ?>
        <div class="mt-4">
            <?php echo e($orders->links()); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ARIO\Documents\Code\my-scrum-project\my-scrum-project\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>